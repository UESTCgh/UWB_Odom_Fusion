#include <ros/ros.h>
#include <std_msgs/Float32MultiArray.h>
#include <vector>
#include <cmath>
#include <algorithm>
#include <Eigen/Dense>

using namespace std;
using namespace Eigen;

// 参数
static const int NUM_COLUMNS = 16;
static const int FIT_WINDOW  = 20;
static const int OVERLAP     = 10;
static const int MAX_BUFFER  = 1000;

// 缓存
vector<vector<double>> columns(NUM_COLUMNS);
vector<double> timestamps;

// 发布器
ros::Publisher pub;

// 多项式拟合
Vector4d polyfit(const vector<double>& x, const vector<double>& y) {
    int N = x.size();
    MatrixXd A(N, 4);
    VectorXd Y(N);
    for (int i = 0; i < N; ++i) {
        A(i, 0) = pow(x[i], 3);
        A(i, 1) = pow(x[i], 2);
        A(i, 2) = x[i];
        A(i, 3) = 1.0;
        Y(i) = y[i];
    }
    return A.colPivHouseholderQr().solve(Y);
}

// 多项式求值
vector<double> polyval(const Vector4d& c, const vector<double>& xs) {
    vector<double> ys;
    ys.reserve(xs.size());
    for (double x : xs) {
        ys.push_back(c[0]*pow(x,3) + c[1]*pow(x,2) + c[2]*x + c[3]);
    }
    return ys;
}

// 回调函数：每收到一帧就立即处理
void matrixCallback(const std_msgs::Float32MultiArray::ConstPtr& msg) {
    double now = ros::Time::now().toSec();
    timestamps.push_back(now);
    if (timestamps.size() > MAX_BUFFER) timestamps.erase(timestamps.begin());

    // 缓存每列
    for (int j = 0; j < NUM_COLUMNS; ++j) {
        double v = (j < (int)msg->data.size()) ? msg->data[j] : 0.0;
        columns[j].push_back(v);
        if (columns[j].size() > MAX_BUFFER) columns[j].erase(columns[j].begin());
    }

    // 数据不够拟合窗口则不处理
    if (timestamps.size() < FIT_WINDOW)
        return;

    vector<double> latest(NUM_COLUMNS, 0.0);

    for (int j = 0; j < NUM_COLUMNS; ++j) {
        auto& buf = columns[j];
        int L = buf.size();
        vector<double> smoothed(L, 0.0);

        for (int i = 0; i + FIT_WINDOW <= L; i += FIT_WINDOW) {
            int start = max(0, i - OVERLAP);
            int end = min(L, start + FIT_WINDOW + OVERLAP);

            vector<double> tx(timestamps.begin() + start, timestamps.begin() + end);
            vector<double> ty(buf.begin() + start, buf.begin() + end);

            Vector4d coeffs = polyfit(tx, ty);
            vector<double> t_fit(timestamps.begin() + i, timestamps.begin() + i + FIT_WINDOW);
            vector<double> v_fit = polyval(coeffs, t_fit);

            for (int k = 0; k < FIT_WINDOW; ++k) {
                smoothed[i + k] = v_fit[k];
            }
        }

        latest[j] = smoothed.back();
    }

    // 构建并发布
    std_msgs::Float32MultiArray out;
    out.layout.dim.resize(2);
    out.layout.dim[0].label = "rows";
    out.layout.dim[0].size = 1;
    out.layout.dim[0].stride = NUM_COLUMNS;
    out.layout.dim[1].label = "cols";
    out.layout.dim[1].size = NUM_COLUMNS;
    out.layout.dim[1].stride = NUM_COLUMNS;
    out.layout.data_offset = 0;

    out.data.clear();
    out.data.reserve(NUM_COLUMNS);
    for (const auto& val : latest) {
        out.data.push_back(static_cast<float>(val));
    }

    pub.publish(out);
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "distance_matrix_smoother_eventdriven");
    ros::NodeHandle nh;

    ros::Subscriber sub = nh.subscribe("/uwb1/distance_matrix", 10, matrixCallback);
    pub = nh.advertise<std_msgs::Float32MultiArray>("/uwb1/distance_matrix/smoothed", 10);

    ros::spin();  // 事件驱动
    return 0;
}
