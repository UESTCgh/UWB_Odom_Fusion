#include <ros/ros.h>
#include <std_msgs/Float32MultiArray.h>
#include <visualization_msgs/MarkerArray.h>

#include <Eigen/Dense>
#include <deque>

#include <gtsam/nonlinear/NonlinearFactorGraph.h>
#include <gtsam/slam/PriorFactor.h>
#include <gtsam/slam/BetweenFactor.h>
#include <gtsam/geometry/Pose2.h>
#include <gtsam/nonlinear/Values.h>
#include <gtsam/nonlinear/LevenbergMarquardtOptimizer.h>
#include <gtsam/inference/Symbol.h>

using namespace gtsam;

class UWBFusionNode {
public:
  UWBFusionNode(ros::NodeHandle& nh) {
    pose_sub_ = nh.subscribe("/uwb1/pose_matrix", 10,
        &UWBFusionNode::poseCallback, this);
    dist_sub_ = nh.subscribe("/uwb1/distance_matrix", 10,
        &UWBFusionNode::distCallback, this);
    fused_pub_ = nh.advertise<std_msgs::Float32MultiArray>(
        "/uwb1/custom_matrix", 10);
    marker_pub_ = nh.advertise<visualization_msgs::MarkerArray>(
        "/uwb1/marker_array", 10);
  }

  void spin() {
    ros::Rate rate(50);
    while (ros::ok()) {
      ros::spinOnce();
      if (pose_ready_ && dist_ready_) {
        processFrame();
        pose_ready_ = dist_ready_ = false;
      }
      rate.sleep();
    }
  }

private:
  // ROS 回调函数
  void poseCallback(const std_msgs::Float32MultiArray::ConstPtr& msg) {
    int dim = DIM_;
    int num_points = msg->data.size() / dim;

    if (num_points <= 0 || msg->data.size() % dim != 0) {
      ROS_WARN("Invalid pose_matrix data size: %zu", msg->data.size());
      return;
    }

    Eigen::Map<const Eigen::Matrix<float, Eigen::Dynamic, 1>> flat_map(msg->data.data(), msg->data.size());
    odom_curr_ = Eigen::MatrixXd::Zero(num_points, dim);
    for (int i = 0; i < num_points; ++i)
      for (int j = 0; j < dim; ++j)
        odom_curr_(i, j) = static_cast<double>(flat_map(i * dim + j));

    pose_ready_ = true;
  }

  void distCallback(const std_msgs::Float32MultiArray::ConstPtr& msg) {
    int len = msg->data.size();
    uwb_dist_ = Eigen::Map<const Eigen::VectorXf>(msg->data.data(), len)
                    .cast<double>();
    dist_ready_ = true;
  }

  void processFrame() {
    if (!is_initialized_) {
      systemInit();
      return;
    }

    optimize();

    est_.push_back(curr_frame_);
    if (est_.size() > frames_window_) est_.pop_front();

    if (est_.size() >= frames_window_) {
      Eigen::MatrixXd sum = Eigen::MatrixXd::Zero(N_, DIM_);
      for (const auto& frame : est_) sum += frame;
      curr_frame_ = sum / est_.size();
    }

    publishResult();
    frame_count_++;
  }

  // 系统初始化：用部分距离信息初始化节点布局，并稳定优化若干轮
  void systemInit() {
    ROS_INFO("[Init] Begin initializing UWB fusion system...");

    curr_frame_ = Eigen::MatrixXd::Zero(N_, DIM_);
    if (uwb_dist_.size() >= 4) {
      curr_frame_(3, 0) = uwb_dist_(3);  // d03
      curr_frame_(1, 1) = uwb_dist_(1);  // d01
      curr_frame_(2, 0) = uwb_dist_(3);  // ≈d02
      curr_frame_(2, 1) = uwb_dist_(1);
    }

    last_frame_ = curr_frame_;
    ROS_INFO("[Init] Running optimization to stabilize initial frame...");

    for (int i = 0; i < 200; ++i) {
      double delta = (curr_frame_ - last_frame_).norm();
      if (delta < 1e-3) {
        ROS_INFO("[Init] Optimization converged at iter %d, delta=%.6f", i, delta);
        break;
      }
      last_frame_ = curr_frame_;
    }

    init_frame_ = curr_frame_;
    is_initialized_ = true;
    ROS_INFO("[Init] Initialization complete.");
  }

  void optimize() {
    NonlinearFactorGraph graph;
    Values initial;

    // 添加先验
    auto priorNoise = noiseModel::Diagonal::Sigmas(
        (Vector(3) << 1e-6, 1e-6, 1e-8).finished());
    graph.add(PriorFactor<Pose2>(Symbol('x', 0), Pose2(0, 0, 0), priorNoise));
    initial.insert(Symbol('x', 0), Pose2(0, 0, 0));

    // 添加一个约束（可扩展成所有 pair）
    double dx = 1.0, dy = 0.5;  // 示例
    auto uwbNoise = noiseModel::Isotropic::Sigma(3, 0.1);
    graph.add(BetweenFactor<Pose2>(Symbol('x', 0), Symbol('x', 1),
                                    Pose2(dx, dy, 0), uwbNoise));
    initial.insert(Symbol('x', 1), Pose2(dx, dy, 0));

    LevenbergMarquardtParams params;
    params.setRelativeErrorTol(1e-5);
    LevenbergMarquardtOptimizer optimizer(graph, initial, params);
    result_ = optimizer.optimize();

    // 结果写入 curr_frame_
    curr_frame_.resize(N_, DIM_);
    for (int i = 0; i < N_; ++i) {
      if (result_.exists(Symbol('x', i))) {
        Pose2 p = result_.at<Pose2>(Symbol('x', i));
        curr_frame_(i, 0) = p.x();
        curr_frame_(i, 1) = p.y();
      }
    }
  }

  void publishResult() {
    std_msgs::Float32MultiArray out;
    for (int i = 0; i < curr_frame_.rows(); ++i)
      for (int j = 0; j < curr_frame_.cols(); ++j)
        out.data.push_back(curr_frame_(i, j));
    fused_pub_.publish(out);
  }

  // 成员变量
  ros::Subscriber pose_sub_, dist_sub_;
  ros::Publisher fused_pub_, marker_pub_;

  Eigen::MatrixXd odom_curr_, uwb_dist_;
  Eigen::MatrixXd curr_frame_, last_frame_, init_frame_;
  Values result_;
  std::deque<Eigen::MatrixXd> est_;

  bool pose_ready_{false}, dist_ready_{false};
  bool is_initialized_{false};

  int N_{4};
  int DIM_{2};
  int frames_window_{48};
  int frame_count_{0};
};

int main(int argc, char** argv) {
  ros::init(argc, argv, "uwb_fusion_node");
  ros::NodeHandle nh;
  ROS_INFO("[Init] UWB Fusion Node starting...");
  UWBFusionNode node(nh);
  node.spin();
  return 0;
}
